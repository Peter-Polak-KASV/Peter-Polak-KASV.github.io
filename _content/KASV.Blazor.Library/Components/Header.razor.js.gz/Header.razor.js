document.getElementsByTagName("header")[0].addEventListener(
    "click",
    function (event)
    {
        alert("Hello world!");
    },
    false);